"""
Permet une interpolation polynomiale par methode des moindre carre

s'appel avec la commande import MC
Exige la creation d'un objet de stokage des donnee 'Donnee()'
ce drernier peut etre initialiser avec des liste via 'maj(x,y,sigma)' ou en ajoutant des donee une par une avec 'add(x,y,sigma)'
L'interpolation se fait avec la fonction 'PolyMC( parametre, Objet 'Donne', pas)'
"""

############################################################################
#Gestion des donné du probleme

class Donnee:
	"contien les donne du probleme"

	__x = [0]; __y = [0]	#Position successive
	__sigma = [1]		#Incertitude sur la position
	__N=1			#nombre de donnee

	#Constructeur
	def __init__(self):
		self.__x = []; self.__y = []
		self.__sigma = []; self.__N=0

	#ajout de valeur
	def add(self,x,y,sigma):
		self.__x.append(x); self.__y.append(y)
		self.__N = self.__N + 1

		#évite la divergence de X2
		D = 0.000001
		if(sigma >= D): __sigma.append(sigma)
		else: 
			__sigma.append(D)
			print("ATTENTION : donne d'entre modifier")

	#mise a jour des valeur
	def maj(self,x,y,sigma):
		self.__x = x; self.__y = y
		self.__sigma = sigma
		self.__N = len(x)

	#assesseur de la position en x
	def posX(self): return(self.__x)

	#assesseur de la position en y
	def posY(self): return(self.__y)

	#assesseur des incertitude
	def sigma(self): return(self.__sigma)

	#assesseur du nombre de point
	def Nb(self): return(self.__N)

############################################################################ OK
#Gestion du polynome d'interpolation

class Poly:
	"Crée un polynome avec la liste de ses coefficients en commensant par celui d'ordre 0"
	__p = [0] #coefficient du polynome

	#Constructeur
	def __init__(self, par): self.__p = par

	#Valeur du polynome en x
	def valeur(self,x):
		S = 0; M = 1
		for k in self.__p :
			S = S + k*M
			M = M * x
		return(S)

	#Valeur du gradient du polynome en x
	def grad(self,x):
		grd = [1]; M = 1
		for k in range(len(self.__p)-1):
			M = M*x
			grd.append(M)
		return(grd) 

	#Asseseur des parametres
	def parametre(self): return(self.__p)

############################################################################ OK
#Gestion du calcul d'erreur

class Erreur:
	"calcul l'erreur carre d'une fonction d'interpolation par rapport à un jeu de donné"

	__f = Poly([0])		#Fonction d'interpolation
	__point = Donnee()	#Donne a interpoler

	__normeGrd = -1		#Norme du gradient

	#Constructeur
	def __init__(self, donne, fct): 
		self.__f = fct; self.__point = donne

	#Calcul de l'erreur carre
	def X2(self):
		x = self.__point.posX(); y = self.__point.posY()
		sigma = self.__point.sigma()

		S = 0
		for i in range(self.__point.Nb()):
			fy = self.__f.valeur(x[i]) #valeur de l'interpolation
			S = S + ((fy - y[i])/sigma[i])**2
		return(S)

	#Calcul du gradient de l'erreur carre
	def gradX2(self):

		#recuperation des donnee
		x = self.__point.posX(); y = self.__point.posY()
		sigma = self.__point.sigma()

		#initialisation du gradiant
		S = []; Is = range(len(self.__f.parametre()))
		for j in Is: S.append(0)

		for i in range(self.__point.Nb()):
			#calcul des valeurs interpolé
			grd = self.__f.grad(x[i])
			fi = self.__f.valeur(x[i])

			#calcul du grad de l'erreur carre pour chaque coordonne
			a = (fi - y[i]) / (sigma[i]**2)
			for j in Is: S[j] = S[j] + a*grd[j]

		self.__normeGrd = 0
		for j in Is: 
			S[j] = 2* S[j]

			#calcul de la norme du gradiant
			self.__normeGrd = self.__normeGrd + S[j]**2
		
		return(S)

	#Affichela norme de gradX2
	def normeGradX2(self):
		if (self.__normeGrd == -1): grd = self.gradX2() #securité
		return(self.__normeGrd)

############################################################################
#Methode des moindre carre par descente du gradient

def PolyMC(par0, donnee, h):
	eps = 0.00000001; #condition d'arret recherche

	loop = True

	while loop:

		fct = Poly(par0); X2 = Erreur(donnee, fct)

		grd = X2.gradX2(); norme = X2.normeGradX2()
		if (norme > eps): 
			for i in range(len(par0)): par0[i] = par0[i] - h*grd[i]
		else : loop = False

	return([X2.X2(),par0])



