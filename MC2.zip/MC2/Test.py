import MC2 as mc
import matplotlib.pyplot as plt

############################################################################
#Creation des point

x = []; y=[]; sigma = []
x0 = -2
m = 1

for i in range(10):
	x.append(x0 + i*m)
	y.append(-x[i]**2 + 2*x[i] + 1)
	sigma.append(1)

############################################################################
#utilisation de la methode

Interpo = mc.MC2([0,0,0])
Interpo.init(x,y,sigma) #pour rentrer directement une liste
"""
Interpo.add(x, y, sigma) #pour ajouter les valeur par itération
"""
a = Interpo.PolyMC(0.0001) #retour de la fonction
b = a[1] #parametre donner par la fonction

############################################################################
#Affichage

X = []
Y = []
for i in range(100): 
	x0 = x[0]; d = (x[-1]-x[0])/100
	X.append(x0 + i*d)
	Y.append(b[0] + b[1]*X[i] + b[2] * X[i]**2)

print(b)
print(a[0])

plt.plot(x,y,"ko")
plt.plot(X,Y)
plt.xlabel("x")
plt.ylabel("y")
plt.show()

