"""
Permet une interpolation polynomiale par methode des moindre carre

s'appel avec la commande 'import MC2'
"""

############################################################################

#Renvoie les valeur d'un polynome de coefficient definie par une liste
def Poly(par,x):

	S = 0; M = 1
	
	for k in par :
		S = S + k*M
		M = M * x
	return(S)

#Valeur du gradient du polynome en x
def gradPoly(par,x):

	grd = [1]; M = 1
	
	for k in range(len(par)-1):
		M = M*x
		grd.append(M)
	return(grd) 
	
############################################################################
	
#Calcul de l'erreur carre
def X2(par, x, y, sigma):

	S = 0
	
	for i in range(len(x)):
		fy = Poly(par, x[i]) #valeur de l'interpolation
		S = S + ((fy - y[i])/sigma[i])**2
	return(S)
	
#Calcul du gradient de l'erreur carre
def gradX2(par, x, y, sigma):

	#initialisation du gradiant
	Npar = len(par)
	S = []; Is = range(Npar)
	for j in Is: S.append(0)
	
	for i in range(Npar):
	
		#calcul des valeurs interpolé
		grd = gradPoly(par, x[i])
		fi = Poly(par, x[i])

		#calcul du grad de l'erreur carre pour chaque coordonne
		a = (fi - y[i]) / (sigma[i]**2)
		for j in Is: S[j] = S[j] + a*grd[j]

	norme = 0
	for j in Is: 
		
		#finition du calcul de l'erreur carre	
		S[j] = 2* S[j]

		#calcul de la norme du gradiant
		norme = norme + S[j]**2
		
	return(norme,S)

############################################################################

class MC2:

	#attribut
	a_par0 = []
	a_x = []; a_y =[]
	a_sigma = []

	#Constructeur
	def __init__(self, par0): 
		self.a_par0 = par0

	#initialiser les point
	def init(self, x, y, sigma): 
		self.a_x = x
		self.a_y = y
		self.a_sigma = sigma

	#ajouté un point
	def add(self, x, y, sigma):
		self.a_x.append(x)
		self.a_y.append(y)
		
		#évite la divergence de X2
		D = 0.000001
		if(sigma >= D): self.a_sigma.append(sigma)
		else: 
			self.a_sigma.append(D)
			return(False)
		
	#Methode des moindre carre par descente du gradient
	def PolyMC(self,h):

		eps = 0.00000001; #condition d'arret recherche
		loop = True

		while loop:
		
			grd = gradX2(self.a_par0, self.a_x, self.a_y, self.a_sigma)
			
			if (grd[0] > eps): 
				for i in range(len(self.a_par0)): 
					self.a_par0[i] = self.a_par0[i] - h*grd[1][i]
					
			else : loop = False
		
		return([X2(self.a_par0, self.a_x, self.a_y, self.a_sigma),self.a_par0])
		

